package com.dycjr.xiakuan.feignagent.utils;

import java.io.ByteArrayInputStream;

import javassist.ClassPool;
import javassist.CtClass;

public class ClassUtil {

    // Modified method to create CtClass from bytecode
    public static CtClass getClass(byte[] classfileBuffer) {
        try {
            ClassPool pool = ClassPool.getDefault();
            return pool.makeClass(new ByteArrayInputStream(classfileBuffer));
        } catch (Exception e) {
            System.out.println("Failed to parse class from bytes");
            e.printStackTrace();
            return null;
        }
    }

    public static CtClass getClass(String className) {
        ClassPool pool = ClassPool.getDefault();

        CtClass clazz = null;

        String name = className.replaceAll("/", ".");

        // 暂不支持内部类
        if (name.contains("$$")) {
            return null;
        }

        try {
            // 需要 com.xxx.xxx 形式才能获取
            clazz = pool.get(name);
        } catch (Throwable e) {
            System.out.println("Class not found: " +  name);
            e.printStackTrace();
        }
        return clazz;
    }
}
