package com.dycjr.xiakuan.feignagent;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import com.dycjr.xiakuan.feignagent.coverter.ApplicationConverter;
import com.dycjr.xiakuan.feignagent.utils.HttpUtil;

import com.netflix.client.config.IClientConfig;
import com.netflix.loadbalancer.AbstractServerList;
import com.netflix.loadbalancer.Server;

import de.codecentric.boot.admin.server.domain.entities.Application;
import de.codecentric.boot.admin.server.domain.entities.Instance;

public class MyDiscoveryServerList extends AbstractServerList<Server> {

    private static Map<String, Application> serverMap = new ConcurrentHashMap<>();

    private static long lastCached = 0L;

    private static long cachedMills = 2 * 60 * 1000L;

    private IClientConfig clientConfig;

    private static final Object lock = new Object();

    @Override
    public List<Server> getInitialListOfServers() {
        return getUpdatedListOfServers();
    }

    @Override
    public List<Server> getUpdatedListOfServers() {
        if (this.clientConfig == null) {
            return new ArrayList<>();
        }
        String listOfServers = findListOfServersByName(this.clientConfig.getClientName());

        System.out.println(this.clientConfig.getClientName() + ".ribbon.listOfServers: " +  listOfServers);

        return derive(listOfServers);
    }

    @Override
    public void initWithNiwsConfig(IClientConfig clientConfig) {
        this.clientConfig = clientConfig;
    }

    private String findListOfServersByName(String serviceName) {
        // 优先读取配置
        Map<String, String> configListOfServers = fetchConfigServers();
        if (configListOfServers.containsKey(serviceName)) {
            return configListOfServers.get(serviceName);
        }

        fetchServers();

        Application application = serverMap.getOrDefault(serviceName, null);
        if (application == null) {
            return "";
        }

        return application.getInstances().stream()
            .filter(instance -> instance.getRegistration() != null)
            .map(instance -> instance.getRegistration().getServiceUrl())
            .filter(url -> url != null)
            .map(url -> url.replace("http://", ""))
            .collect(Collectors.joining(Constants.COMMA));
    }

    public static Map<String, String> fetchConfigServers() {
        return System.getenv().entrySet().stream()
                .filter(entry -> entry.getKey().startsWith(Constants.LIST_OF_SERVERS_CONFIG_PREFIX))
                .map(entry -> {
                    String key = entry.getKey().replace(Constants.LIST_OF_SERVERS_CONFIG_PREFIX, "");
                    return new AbstractMap.SimpleEntry<String, String>(key, normalizeServers(entry.getValue()));
                })
                .filter(entry -> !entry.getKey().isEmpty() && !entry.getValue().isEmpty())
                .collect(
                    Collectors.toMap(
                        Map.Entry::getKey, Map.Entry::getValue,
                        (v1, v2) -> normalizeServers(v1 + Constants.COMMA + v2)
                    )
                );
    }

    public static String normalizeServers(String listOfServers) {
        if (listOfServers == null) {
            return "";
        }

        return Arrays.stream(listOfServers.split(Constants.COMMA))
                .map(str -> str.trim())
                .filter(str -> !str.isEmpty() &&  !"null".equals(str))
                .distinct()
                .collect(Collectors.joining(Constants.COMMA));
    }

    public synchronized void fetchServers() {
        long currTime = System.currentTimeMillis();

        if (checkIfExpired()) {
            System.out.println("Caching discovery...remains " + ((lastCached + cachedMills - currTime) / 1000));
            return;
        }

        String env = System.getenv(Constants.DISCOVERY_ENV);
        if (env == null || env.isEmpty()) {
            env = "test1";
        }

        System.out.println(Constants.DISCOVERY_ENV + " : " + env);

        String appList = HttpUtil.discovery(env);

        List<Application> servers = ApplicationConverter.ofList(appList);

        Map<String, Application> innerServerMap = new ConcurrentHashMap<>();

        for (Application server : servers) {
            if (!"UP".equals(server.getStatus())) {
                continue;
            }

            List<Instance> instances = server.getInstances().stream()
                                            .filter(instance -> instance.getStatusInfo() != null)
                                            .filter(instance -> "UP".equals(instance.getStatusInfo().getStatus()))
                                            .collect(Collectors.toList());

            if (instances.isEmpty()) {
                continue;
            }

            innerServerMap.put(server.getName(), server);
        }

        putMap(innerServerMap);

        setLastCached();
    }

    private static void putMap(Map<String, Application> innerServerMap) {
        synchronized (lock) {
            serverMap.clear();
            serverMap.putAll(innerServerMap);
        }
    }

    private static boolean checkIfExpired() {
        long currTime = System.currentTimeMillis();

        synchronized (lock) {
            return lastCached + cachedMills >= currTime;
        }
    }

    private static void setLastCached() {
        synchronized (lock) {
            lastCached = System.currentTimeMillis();
        }
    }

    private static List<Server> derive(String listOfServers) {
	    List<Server> list = new ArrayList<>();
		if (listOfServers == null || listOfServers.trim().isEmpty()) {
			return list;
		}
        for (String server: listOfServers.trim().split(",")) {
            if (server.trim().isEmpty()) {
                continue;
            }
            list.add(new Server(server.trim()));
        }
        return list;
	}

}
