package com.dycjr.xiakuan.feignagent;

import org.springframework.cloud.netflix.ribbon.RibbonClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.netflix.loadbalancer.Server;
import com.netflix.loadbalancer.ServerList;

@Configuration(proxyBeanMethods = false)
@RibbonClients(defaultConfiguration = LocalRibbonConfiguration.CustomRibbonConfiguration.class)
public class LocalRibbonConfiguration {

    public LocalRibbonConfiguration() {
        System.out.println(">>>>>>>>>> Ribbon配置已加载 <<<<<<<<<<");
    }

    @Configuration
    public static class CustomRibbonConfiguration {
        @Bean
        public ServerList<Server> ribbonServerList() {  // 移除参数依赖
            System.out.println(">>>>>>>>>> 创建自定义ServerList <<<<<<<<<<");
            return new MyDiscoveryServerList();
        }
    }
}

// @Configuration
// class CustomRibbonConfiguration {
//     @Bean
// 	public ServerList<Server> ribbonServerList(@Autowired(required = false) IClientConfig config) {
//         System.out.println(">>>>>>>>>> 创建自定义ServerList <<<<<<<<<<");
//         MyDiscoveryServerList serverList = new MyDiscoveryServerList();
//         if (config != null) {
//             serverList.initWithNiwsConfig(config);
//         }

//         return serverList;
//     }

//     public CustomRibbonConfiguration() {
//         System.out.println("---------------CustomRibbonConfiguration");
//     }
// }
