package com.dycjr.xiakuan.feignagent;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Import(LocalRibbonConfiguration.class)
@ComponentScan("com.dycjr.xiakuan.feignagent") // 添加扫描路径
@Documented
public @interface EnableMyDiscovery {
}
